#!/bin/bash

rm -f sinrom
