
void _gdb_write_char (char c);
char _gdb_read_char (void);
void _gdb_ack_interrupt (void) ;

