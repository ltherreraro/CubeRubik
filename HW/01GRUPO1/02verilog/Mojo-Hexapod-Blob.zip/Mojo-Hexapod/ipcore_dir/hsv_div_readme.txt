The following files were generated for 'hsv_div' in directory
/home/justin/workspace/Mojo-Hexapod/ipcore_dir/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * hsv_div.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * hsv_div.ngc
   * hsv_div.v
   * hsv_div.veo

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * hsv_div.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * hsv_div.asy

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * hsv_div_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * hsv_div.gise
   * hsv_div.xise

Deliver Readme:
   Readme file for the IP.

   * hsv_div_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * hsv_div_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

